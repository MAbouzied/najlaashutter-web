/* JS Scripts Here */
/* General */
let gal = document.querySelectorAll(".wp-block-gallery a")
gal.forEach((i) => {
    i.setAttribute("data-fancybox","gallery")
} )
Fancybox.bind("[data-fancybox]", {});
AOS.init();
/* jQuery */
jQuery(function(){
    jQuery("#pw-search-modal").on('shown.bs.modal', function(){
        jQuery(this).find('#pw-search-form-1').focus();
    });
    jQuery(window).scroll(function(){
        if(jQuery(this).scrollTop()>60) {
            jQuery(".nav-logo").removeClass("naj");
        } else {
            jQuery(".nav-logo").addClass("naj");
        }
    });
    jQuery(".bktop").click(function(){
        window.scrollTo({top: 0, behavior: 'smooth'});
    });
});
/* Swipers */
var swiper = new Swiper(".pw-hom-swp1", {
    slidesPerView: 1.3,
    spaceBetween: 30,
    autoplay: {
        delay: 2500,
        disableOnInteraction: false,
    },
    pagination: {
        el: ".pw-hom-pag1",
        clickable: true,
    },
    navigation: {
        nextEl: ".pw-hom1-next",
        prevEl: ".pw-hom1-prev",
    },
    breakpoints: {
        768: {
            slidesPerView: 2,
            spaceBetween: 30,
        },
        1024: {
            slidesPerView: 4,
            spaceBetween: 30,
        },
    },
});
var swiper = new Swiper(".pw-hom-swp2", {
    slidesPerView: 1.2,
    spaceBetween: 30,
    autoplay: {
        delay: 5000,
        disableOnInteraction: false,
    },
    pagination: {
        el: ".pw-hom-pag2",
        clickable: true,
    },
    navigation: {
        nextEl: ".pw-hom2-next",
        prevEl: ".pw-hom2-prev",
    },
    breakpoints: {
        768: {
            slidesPerView: 2,
            spaceBetween: 30,
        },
        1024: {
            slidesPerView: 3,
            spaceBetween: 30,
        },
    },
});
var swiper = new Swiper(".pw-hom-swp3", {
    slidesPerView: 1.2,
    spaceBetween: 30,
    loop: true,
    autoplay: {
        delay: 3000,
        disableOnInteraction: false,
    },
    pagination: {
        el: ".pw-hom-pag3",
        clickable: true,
    },
    navigation: {
        nextEl: ".pw-hom3-next",
        prevEl: ".pw-hom3-prev",
    },
    breakpoints: {
        768: {
            slidesPerView: 3,
            spaceBetween: 30,
        },
        1024: {
            slidesPerView: 3,
            spaceBetween: 30,
        },
    },
});
var swiper = new Swiper(".pw-hom-swp4", {
    slidesPerView: 2,
    spaceBetween: 5,
    autoplay: {
        delay: 3500,
        disableOnInteraction: false,
    },
    pagination: {
        el: ".pw-hom-pag4",
        clickable: true,
    },
    navigation: {
        nextEl: ".pw-hom4-next",
        prevEl: ".pw-hom4-prev",
    },
    breakpoints: {
        768: {
            slidesPerView: 3,
            spaceBetween: 10,
        },
        1024: {
            slidesPerView: 4,
            spaceBetween: 20,
        },
    },
});